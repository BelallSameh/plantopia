package com.example.plantopia

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
